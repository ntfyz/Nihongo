# Nihongo 1–25 (iOS)

Ứng dụng SwiftUI luyện dịch Việt → Nhật theo nội dung ngữ pháp Minna no Nihongo sơ cấp, bài 1–25.

## Nội dung hiện có
- Chọn riêng từng bài 1–25 hoặc bật ôn tập tổng hợp.
- 50 câu dịch tự biên soạn (2 câu/bài), không sao chép nguyên văn bài tập trong sách.
- Nhập đáp án tiếng Nhật, kiểm tra với các đáp án được chấp nhận.
- Hiển thị đáp án tham khảo, trọng tâm và giải thích.
- Hoạt động offline.

## Giới hạn chấm bài
Bản này chấm theo đáp án mẫu và biến thể đã khai báo, không phải AI hiểu ngữ nghĩa tự do. Câu đúng nhưng diễn đạt khác đáp án được liệt kê có thể bị đánh dấu chưa chính xác. Phần gợi ý lỗi là heuristic, không phải phân tích ngữ pháp đầy đủ.

## Build bằng GitHub
1. Tạo repository GitHub mới.
2. Upload toàn bộ thư mục này lên repository, giữ nguyên `.github/workflows/ios.yml`.
3. Mở tab **Actions** → workflow **Build unsigned IPA** → **Run workflow**.
4. Đợi job hoàn tất, mở phần **Artifacts**, tải `Nihongo25-unsigned-IPA`.
5. Giải nén artifact để lấy `Nihongo25-unsigned.ipa`.

GitHub Actions cài XcodeGen, tạo project Xcode từ `project.yml`, build bằng runner macOS và đóng gói `.app` thành IPA chưa ký.

## Cài lên iPhone
IPA chưa ký không cài trực tiếp được. Cần ký bằng chứng chỉ/profile hợp lệ (ví dụ Apple Development hoặc phương thức ký phù hợp) trước khi cài. Workflow này không chứa chứng chỉ và không tự ký app.

## Build local (Mac)
Cài Xcode và XcodeGen, sau đó:
```bash
brew install xcodegen
xcodegen generate
xcodebuild -project Nihongo25.xcodeproj -scheme Nihongo25 -sdk iphoneos -configuration Release CODE_SIGNING_ALLOWED=NO build
```
